apt-get update
apt-get install telnetd -y
Addduser eru_spy
apt-get install xinetd telnetd -y
nano /etc/xinetd.d/telnet
service xinetd restart
telnet 10.74.2.1
Eru_spy
123
exit