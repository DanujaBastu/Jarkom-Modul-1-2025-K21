apt-get update
apt-get install netcat -y
# buka port
nc -l -p 21 &
nc -l -p 80 &
# cek port
nc -zv [IP Prefix_Melkor] 21
nc -zv [IP Prefix_Melkor] 80
nc -zv [IP Prefix_Melkor] 666