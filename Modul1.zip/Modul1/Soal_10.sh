ping -c 100 10.74.1.1 di melkor
