apt-get update
apt-get install openssh-server -y
service ssh start

apt-get update
apt-get install openssh-client -y

adduser test
echo "test:[password]" | chpasswd

ssh test@[IP Prefix_Eru]

ssh || tcp.port == 22