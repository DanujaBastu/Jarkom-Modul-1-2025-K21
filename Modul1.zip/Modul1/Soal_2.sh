telnet 10.15.43.32 5091
ping google.com 