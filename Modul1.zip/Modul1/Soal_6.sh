nano traffic.sh
chmod +x traffic.sh
 ./traffic.sh
#Ditambah dengan Wireshark yang melakukan scanning ke wsl
