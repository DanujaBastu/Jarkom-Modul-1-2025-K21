wget --no-check-certificate 'https://drive.google.com/uc?export=download&id=11ra_yTV_adsPIXeIPMSt0vrxCBZu0r33' -O cuaca.zip
Ke gns3 client, lalu membuka wireshark dari situ dengan klik kanan lalu capture di connection antara switch dengan ulmo
#Kembali ke terminal lalu masuk ke ftp
ftp 10.74.2.1 
#Login ke Ainur
#Lalu jalankan 
put cuaca.zip
#Setelah itu kembali ke wireshark dan melakukan display filter yaitu ftp || ftp-data
#Berikut adalah hasilnya

#Untuk double check, bisa kembali ke terimal dan ke bagian eru lalu jalankan 
ls -l /var/ftp/shared
