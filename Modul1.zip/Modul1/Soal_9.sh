wget --no-check-certificate 'https://drive.google.com/uc?export=download&id=11ua2KgBu3MnHEIjhBnzqqv2RMEiJsILY' -O /var/ftp/shared/Kitab_Penciptaan.zip
sudo chmod 755 /var/ftp/shared/
#Lalu melakukan capture dari gns client dengan node dari manwe ke switch
#Melakukan login ke ainur melalui ftp
ftp 10.74.1.1 
ftp> get Kitab_Penciptaan.zip
#Lalu ke wireshark dan melakukan display filter dengan filter (ftp || ftp-data)
#Lalu akan mendapat ini

#Lalu untuk mengetest ainur di read only, kita menggunakan sudo chmod 755 /var/ftp/shared/upload/
#Lalu kita bisa check dengan ftp> get Kitab_Penciptaan.txt di ftp ainur seperti yang ada di bawah ini
