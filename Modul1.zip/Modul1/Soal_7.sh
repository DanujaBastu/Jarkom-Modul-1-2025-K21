Instal vsftpd
apt-get update
apt-get install vsftpd
#Buat directory & menamba user
mkdir -p /var/ftp/shared
adduser ainur 
adduser melkor
nano /etc/vsftpd.conf
#Pastikan baris-baris berikut ada dan tidak diawali tanda #:
local_enable=YES
write_enable=YES
chroot_local_user=YES
allow_writeable_chroot=YES
local_root=/var/ftp/shared
userlist_enable=YES
userlist_file=/etc/vsftpd.userlist
userlist_deny=NO
nano /etc/vsftpd.userlist(isi dengan ainur)
#Membuat grup khusus untuk ainur
addgroup ftpaccess 
adduser ainur ftpaccess 
chgrp ftpaccess /var/ftp/shared/ 
chmod 775 /var/ftp/shared/
#Menjalankan vstpd
service vsftpd restart
Install ftp di node
apt-get update 
apt-get install ftp
echo "Ini adalah file bukti dari Ainur" > file_bukti.txt
Login ke user ainur
ftp 10.74.1.1 
put file_bukti.txt 
ftp> ls 
ftp> quit
ftp 10.74.1.1 
Malkor
Pasti gagal
